module.exports = {
    'database': 'mongodb://stadmin:7u8i9o0p@ds133004.mlab.com:33004/sharedthoughtdb'
};